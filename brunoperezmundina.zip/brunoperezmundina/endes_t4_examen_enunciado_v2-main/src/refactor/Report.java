package refactor;

/*
Extraer la impresión del título y conclusión en sus propios métodos.
 */
class Report {

    void printReport() {
        // imprimir título
        System.out.println("Título del Reporte");

        // contenido del reporte
        System.out.println("Contenido 1...");
        System.out.println("Contenido 2...");
        // más contenido...

        // imprimir conclusión
        System.out.println("Conclusión del Reporte");

    }

    // Método para imprimir el título del reporte
    private void printTitle() {
        System.out.println("Título del Reporte");
    }
    //metodo para imprimir el contenido
    private void printcontent() {
        System.out.println("contenido------");
    }


    // Método para imprimir la conclusión del reporte
    private void printConclusion() {
        System.out.println("Conclusión del Reporte");
    }
}