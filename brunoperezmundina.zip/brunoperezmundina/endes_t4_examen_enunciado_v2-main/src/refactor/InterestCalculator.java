package refactor;

/*
 * Refactoriza el siguiente código de forma para evitar utilizar un número mágico
 * y repetir el número cada vez que se utiliza.
 */
public class InterestCalculator {
    // Método para calcular el interés compuesto
    double calculateInterest(double principal, double rate, int time) {
        final int daysInYear = 365;
        double effectiveRate = rate / daysInYear;
        double totalDays = time * daysInYear;
        // Cálculo del interés compuesto con la tasa efectiva y el tiempo total en días
        return principal * Math.pow(1 + effectiveRate, totalDays);
    }
}