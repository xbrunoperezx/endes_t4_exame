package refactor;

/*
 * Utiliza nombres más descriptvos para las variables.
 */

public class DistanceCalculator {

    double width;
    double height;

    public double calculateDistance(double width, double height) {
        return width * height;
    }
}
