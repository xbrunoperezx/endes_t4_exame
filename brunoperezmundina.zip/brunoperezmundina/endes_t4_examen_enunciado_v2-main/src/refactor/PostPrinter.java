package refactor;

public class PostPrinter {
}
