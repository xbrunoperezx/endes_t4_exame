


/**
 * creacion de una clase  que represneta un cliente
 * realizaremos clase cliente para asignarle unos parametros de nombre apellidos ,id , listaarrays
 * atributos necesarios para cada atributo del cliente
 * @author Bruno / Tunivers
 * @version 1.0 12/03/2024
 */
public class Cliente {
    /**
     * es el nombre de la persona de la  clase cliente
     */
    private String nombre;
    /**
     * es el apellido de la persona de la clase cliente
     */
    private String apellido;
    /**
     * es la id de la persona de la clase cliente
     */
    private String id;
    /**
     * lsita de array donde contiene cuentas de la clase cliente
     */
    private List<CuentaBancaria> cuentas;

    /**
     * Constructor para crear un nuevo cliente con nombre, apellido e identificación.
     * @param nombre El nombre del cliente.
     * @param apellido El apellido del cliente.
     * @param id La identificación del cliente.
     */
    public Cliente(String nombre, String apellido, String id) {

        this.nombre = nombre;
        this.apellido = apellido;
        this.id = id;
        this.cuentas = new ArrayList<>();
    }

    /**
     * Método para obtener el nombre del cliente.
     * @return El nombre del cliente.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Método para establecer el nombre del cliente.
     * @param nombre El nuevo nombre del cliente.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Método para obtener el apellido del cliente.
     * @return El apellido del cliente.
     */
    public String getApellido() {
        return apellido;
    }

    /**
     * Método para establecer el apellido del cliente.
     * @param apellido El nuevo apellido del cliente.
     */
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    /**
     * Método para obtener la identificación del cliente.
     * @return La identificación del cliente.
     */
    public String getId() {
        return id;
    }

    /**
     * Método para establecer la identificación del cliente.
     * @param id La nueva identificación del cliente.
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Método para obtener una copia de la lista de cuentas bancarias del cliente.
     * @return Una copia de la lista de cuentas bancarias del cliente.
     */
    public List<CuentaBancaria> getCuentas() {
        return new ArrayList<>(cuentas);
    }

    /**
     * Método para agregar una nueva cuenta bancaria al cliente.
     * @param cuenta La cuenta bancaria que se va a agregar.
     */
    public void agregarCuenta(CuentaBancaria cuenta) {
        cuentas.add(cuenta);
    }

    /**
     * Método para cerrar una cuenta bancaria del cliente dado su número de cuenta.
     * @param numeroCuenta El número de la cuenta bancaria que se desea cerrar.
     * @return true si la cuenta se cerró con éxito, false si no se encontró la cuenta.
     */
    public boolean cerrarCuenta(String numeroCuenta) {
        return cuentas.removeIf(cuenta -> cuenta.getNumeroCuenta().equals(numeroCuenta));
    }

    /**
     * Método para obtener una representación en cadena del cliente, incluyendo su nombre, apellido, identificación y cuentas bancarias.
     * @return Una cadena que representa al cliente.
     */
    @Override
    public String toString() {
        return "Cliente{" +
                "nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", id='" + id + '\'' +
                ", cuentas=" + cuentas +
                '}';
    }
}